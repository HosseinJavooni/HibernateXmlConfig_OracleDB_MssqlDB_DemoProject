create FUNCTION my_sleep(n NUMBER)
RETURN NUMBER 
IS 
BEGIN
dbms_session.sleep(n);
RETURN n;
END;
/

