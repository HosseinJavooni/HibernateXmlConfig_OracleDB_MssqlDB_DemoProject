create FUNCTION my_sleep(n NUMBER)
RETURN NUMBER 
IS 
n NUMBER(1);
BEGIN
dbms_session.sleep(10);
RETURN n;
END;
/

